# 1.1 Question of Interest
# The main question of this study is to identify the underlying factors that can predict the risk of developing diabetes.
# Specifically, we are interested in reducing the dimensionality of the data to identify key factors among the 
# continuous variables (e.g., Glucose, Blood Pressure, etc.) that contribute to diabetes risk.

# 1.2 Exploratory Data Analysis (EDA)

# Load the dataset
setwd("/Users/sunthewhat/Documents/Babii/yr2_sem1/cpa/Factor_Analysis")  # Set Working Directory
data <- read.csv("./Data.csv", header=TRUE)                               # Read data from file

# Display the structure and summary statistics of the dataset
str(data)
summary(data)

# Select the variables of interest for factor analysis
fac1 <- subset(data, select=c(Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, Age))

# Descriptive statistics
library(psych)
describe(fac1)

# Correlation matrix
cor_matrix <- cor(fac1)
print(cor_matrix)

# Check for the suitability of data for factor analysis
cortest.bartlett(cor_matrix)
KMO(cor_matrix)

# Interpretation of EDA results:
# The descriptive statistics provide insights into the distribution, central tendency, and variability of each variable.
# The correlation matrix helps to understand the relationships between the variables.
# The Bartlett's test of sphericity and KMO measure indicate whether the dataset is suitable for factor analysis.

# 1.3 Factor Analysis

# Calculate the eigenvalues to determine the number of factors to retain
eigenvalues <- eigen(cor(fac1))$values
print(eigenvalues)

# Scree plot to visualize eigenvalues
quartz(); scree(fac1)

# Perform the factor analysis with 2 factors (based on scree plot) and varimax rotation
fa1 <- fa(r=fac1, nfactors=2, rotate="varimax", n.obs=nrow(fac1), fm="pa")

# Display the factor analysis results
print(fa1)

# Interpretation:
# The factor analysis results provide the factor loadings, which indicate the correlation of each variable with the underlying factors.
# The varimax rotation simplifies the factor structure by making the loadings more interpretable.

# 1.4 Total Variance Explained

# Calculate the communalities and total variance explained by the factors
communalities <- fa1$communality
total_variance_explained <- sum(fa1$e.values) / ndim1 * 100

# Interpretation:
# The total variance explained by the factor model is the sum of the eigenvalues of the retained factors divided by the number of variables.
# This value indicates the proportion of the total variance in the data that can be attributed to the factors.
print(paste("Total Variance Explained:", total_variance_explained, "%"))

# 1.5 Interpretation of Factor Analysis Results

# Factor loadings
loadings <- fa1$loadings[1:ndim1,]
round(loadings, 3)

# Communality estimates and uniqueness
communalities <- fa1$communality
uniqueness <- fa1$unique

# Interpretation:
# The factor loadings reveal which variables are most strongly associated with each factor.
# High loadings indicate a strong association with the underlying factor.
# The communalities show the proportion of variance in each variable explained by the factors.
# The uniqueness values indicate the proportion of variance that is unique to each variable and not explained by the factors.
