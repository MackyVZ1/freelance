# Import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Generate simulated data
np.random.seed(0)
advertisement_budget = np.random.uniform(10, 50, 100)
sales = 2.5 * advertisement_budget + np.random.normal(0, 5, 100)

# Create DataFrame
data = pd.DataFrame({'Advertisement_Budget': advertisement_budget, 'Sales': sales})

# Create Linear Regression Model
X = data[['Advertisement_Budget']]
y = data['Sales']

model = LinearRegression()
model.fit(X, y)

# Predict values
y_pred = model.predict(X)

# Calculate MSE and RMSE
mse = mean_squared_error(y, y_pred)
rmse = np.sqrt(mse)

# Display results
print("Coefficients:", model.coef_)
print("Intercept:", model.intercept_)
print("MSE:", mse)
print("RMSE:", rmse)

# Plot
plt.scatter(X, y, color='blue', label='Actual Data')
plt.plot(X, y_pred, color='red', label='Fitted Line')
plt.xlabel('Advertisement Budget')
plt.ylabel('Sales')
plt.legend()
plt.show()