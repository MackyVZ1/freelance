library(ggplot2)

advertisement_budget <- c(10, 20, 30, 40, 50)
sales <- c(15, 25, 30, 35, 40)

data <- data.frame(AdvertisementBudget = advertisement_budget, Sales = sales)

slr_model <- lm(Sales ~ AdvertisementBudget, data = data)

summary(slr_model)

ggplot(data, aes(x = AdvertisementBudget, y = Sales)) +
  geom_point() +
  geom_smooth(method = "lm", col = "blue") +
  labs(title = "Simple Linear Regression: Advertisement Budget vs Sales",
        x = "Advertisement Budget (in thousands)",
        y = "Sales (in thousands)")

plot(slr_model, which = 1)
plot(slr_model, which = 2)
plot(slr_model, which = 3)

data <- datal.frame(advertisement_budget, sales)

plot(data$advertisement_budget, data$sales,
    main = "Scatterplot: Advertisement Budget vs Sales",
    xlab = "Advertisement Budget (in thousands)",
    ylab = "Sales (in thousands)",
    pch = 16,
    col = "green")
grid()

model <- lm(sales ~ advertisement_budget)

residuals <- model$residuals

qqnorm(residuals, main = "Q-Q Plot: Residuals of Linear Model")
qqline(residuals, col = "red")

install.packages("lmtest")
library(lmtest)

dw_test <- durbinWatsonTest(model)

advertisement_budget -< c(10, 20, 30, 40, 50)
sales <- c(15, 25, 30, 35, 40)

model <- lm(sales ~ advertisement_budget)

residuals <- model$residuals

shapiro_test <- shapiro.test(residuals)

print(shapiro_test)

advertisement_budget <- c(10, 20, 30, 40, 50)
sales <- c(15, 25, 30, 35, 40)

model <- lm(sales ~ advertisement_budget)

predictions <- predict(model)

residuals <- sales - predictions

mse <- mean(residuals^2)
print(paste("Mean Squared Error (MSE):", mse))

rmse <- sqrt(mse)
print(paste("Root Mean Squared Error (RMSE):", rmse))

rsq <- summary(model)$r.squared
print(paste("R-squared:", rsq))

adj_rsq <- summary(model)$adj.r.squared
print(paste("Adjusted R-squared:", adj_rsq))

plot(predictions, residuals,
    main = "Residuals vs Fitted Values",
    xlab = "Fitted Values",
    ylab = "Residuals",
    pch = 16,
    col = "blue")
abline(h = 0, col = "red")