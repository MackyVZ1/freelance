# Import necessary libraries
library("ggplot2")
library("corrplot")
library("factoextra")

# 1.1 What is the question of interest of this study that you are attempting to answer?
# -> We need to predict risk of developing diabetes

# Set working directory
setwd("/Users/sunthewhat/Documents/Babii/yr2_sem1/cpa/diabetes_aj")

# Read file from `Data.csv`
data <- read.csv("./Data.csv", header=TRUE)

# Remove unwanted column
data <- data[ ,1:8]

# Descriptive Statistic (1.2)
str(data)
summary(data)
cor(data)
corrplot(cor(data), method="circle")
ggplot(data, aes(x=Pregnancies)) + geom_histogram(binwidth = 1) + ggtitle("Pregnancies")
ggplot(data, aes(x=Glucose)) + geom_histogram(binwidth = 5) + ggtitle("Glucose")
ggplot(data, aes(x=BloodPressure)) + geom_histogram(binwidth = 5) + ggtitle("BloodPressure")
ggplot(data, aes(x=SkinThickness)) + geom_histogram(binwidth = 2) + ggtitle("SkinThickness")
ggplot(data, aes(x=Insulin)) + geom_histogram(binwidth = 10) + ggtitle("Insulin")
ggplot(data, aes(x=BMI)) + geom_histogram(binwidth = 1) + ggtitle("BMI")
ggplot(data, aes(x=DiabetesPedigreeFunction)) + geom_histogram(binwidth = 0.05) + ggtitle("DiabetesPedigreeFunction")
ggplot(data, aes(x=Age)) + geom_histogram(binwidth = 1) + ggtitle("Age")

# PCA by the "prcomp" package (1.3)
pc <- prcomp(data[,c(2,6,8)],scale=TRUE)
# 1.4 Explain how you select the number of components to be retained.
# -> remove PC1,3,4,5&7 because lamda1,3,4,5&7 near zero, multicollinearity is represent.
summary(pc)
pc$sdev         # Which slide? ## slide 24: eigenvalue = variance = sd^2
pc$rotation     # Which slide? ## slide 24: eigenvector
pc$x            # Which slide? ## slide 33: PC score

  # write.csv(pc$x, file="pc.csv")

# Visualize Data and result (1.5)
fviz_pca_ind(pc, col.ind = "cos2", gradient.cols = c("#FF0000", "#00FF00", "#0000FF"),label = "none")

pca_summary <- summary(pc)
print(pca_summary)

